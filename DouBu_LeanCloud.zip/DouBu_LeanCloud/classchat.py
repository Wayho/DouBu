# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
# Standard library imports

###################### Class Define #######################
class Class_Chat():
	# 处理 Chat Class的存取，没有属性，仅提供方法


	def Add(self, sOpenid,sQuestion,sAnswer):
		# 返回 objectId
		# 检查存过没有
		ChatClass = leancloud.Object.extend( self.__DBClassName )

		dB = ChatClass()
		dB.set('openid', sOpenid) #展开sOpenid
		dB.set('Question', sQuestion)
		dB.set('Answer', sAnswer)
		dB.save()
		print('Add:',sOpenid,sQuestion,sAnswer)
		return dB.id

	############## private #####
	def __init__(self):
		self.__DBClassName = "Chat"


##########################Do not delete############################
CHAT_CLASS = Class_Chat()