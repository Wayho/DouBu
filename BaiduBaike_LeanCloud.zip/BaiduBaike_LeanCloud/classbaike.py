# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
# Standard library imports

from datetime import datetime, timedelta
import time,re
import os
import codecs
# local imports


DATE_LIST_NUM = 180
LIMIT_QUERY = 500

###################### Class Define #######################
class Class_Baike():
	# 处理 Baike Class的存取，没有属性，仅提供方法

	def Find_Not_Expand(self):
		# 返回 Title
		# 检查Expand没有
		BaikeClass = leancloud.Object.extend(self.__DBClassName)
		query = BaikeClass.query
		#query.add_ascending('updatedAt')    ## 按时间，升序排列
		query.add_ascending('createdAt')  ## 按时间，升序排列
		query.select('Expand','Title')
		query.equal_to('Expand', False)
		aFinds = query.find()
		if (len(aFinds) == 0):
			return None
		else:
			return aFinds[0].get('Title')

	def Add(self, sTitle):
		# 返回 objectId
		# 检查存过没有
		BaikeClass = leancloud.Object.extend( self.__DBClassName )

		objectId = self.Get_objectId_By_Title(sTitle)
		if (objectId is None):
			dB = BaikeClass()
			dB.set('Title', sTitle)
			dB.set('Expand', False) #展开链接否
			dB.save()
			print('Add:',sTitle)
			return dB.id
		else:
			return None

	def Update_Content(self, sTitle, sContent, bExpand):
		# 返回 objectId
		# 检查存过没有
		BaikeClass = leancloud.Object.extend( self.__DBClassName )

		objectId = self.Get_objectId_By_Title(sTitle)
		if (objectId is None):
			return None
		else:
			dB = BaikeClass.create_without_data(objectId)
			dB.set('Content', sContent)
			dB.set('Expand', bExpand)  # 展开链接否
			dB.save( )
			print('Update_Content:', sTitle)
			return dB.id

	def Get_objectId_By_Title(self,sTitle):
		BaikeClass = leancloud.Object.extend(self.__DBClassName)
		query = BaikeClass.query
		query.select('Title','objectId')
		query.equal_to('Title', sTitle)
		aFind = query.find()
		if(len(aFind)==0):
			return None
		else:
			return aFind[0].get('objectId')

	def Get_List_Title(self):
		BaikeClass = leancloud.Object.extend(self.__DBClassName)
		query = BaikeClass.query
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		query.select('Title')
		aRet = []
		page = 0
		while(True):
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			aFind = query.find()
			print('Page:', page,'Find',len(aFind))
			if (len(aFind) == 0):
				break;
			for tmp in aFind:
				aRet.append(tmp.get('Title'))
			page = page + 1
		return aRet

	def Get_List_Content(self):
		BaikeClass = leancloud.Object.extend(self.__DBClassName)
		query = BaikeClass.query
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		query.select('Title','Content')
		query.equal_to('Expand', True)
		aRet = []
		page = 0
		while(True):
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			aFind = query.find()
			print('Page:', page,'Find',len(aFind))
			if (len(aFind) == 0):
				break;
			for tmp in aFind:
				aRet.append(tmp)
			page = page + 1
		return aRet

	def To_yml(self):
		sFileText = "categories:\n- 电力工程\nconversations:\n"
		aItems = self.Get_List_Content()
		print("Baike array length:", len(aItems))
		i = 1
		for item in aItems:
			if(item.get("Content")):
				sFileText += '- - ' + self.Delete_Char(item.get("Title")) + '\n' + '  - ' + self.Delete_Char(item.get("Content")) + '\n'
			if(len(sFileText)>400000):
				self.Save_To_File('BaiduBaike' + str(i) + '.yml', sFileText)
				i += 1
				sFileText = "categories:\n- 电力工程\nconversations:\n"
		self.Save_To_File('BaiduBaike' + str(i) + '.yml', sFileText)

	def Delete_Char(self,sText):
		sText = sText.replace('\n', '')
		sText = sText.replace('\r', '')
		sText = sText.replace('[', '')
		sText = sText.replace(']', '')
		sText = sText.replace(':', ' ')
		sText = sText.replace('\"', '')
		sText = sText.replace('\'', '')
		sText = sText.replace('\t', ' ')
		sText = self.Delete_None_Printable(sText)
		return sText

	def Save_To_File(self,sFileName, sText):
		ffile = codecs.open(sFileName, 'w', 'utf-8')
		ffile.write(sText)
		ffile.close()

	# 提前在.pyenv/versions/3.6.4/lib/python3.6/site-packages/yaml/reader.py前面处理
	def Delete_None_Printable(self, sText):
		NON_PRINTABLE = re.compile('[^\x09\x0A\x0D\x20-\x7E\x85\xA0-\uD7FF\uE000-\uFFFD]')
		match = True
		while match:
			match = NON_PRINTABLE.search(sText)
			if match:
				character = match.group()
				print(match.start(), ord(character))
				sText = sText.replace(character, '')
		return sText

	############## private #####
	def __init__(self):
		self.__DBClassName = "Baike"


##########################Do not delete############################
BAIKE_CLASS = Class_Baike()