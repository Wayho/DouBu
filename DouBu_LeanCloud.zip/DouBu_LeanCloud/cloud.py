# coding: utf-8

from leancloud import Engine
from leancloud import LeanEngineError

import subprocess
import select


from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
import chatterbot
print(chatterbot.__version__)

from classchat import CHAT_CLASS

engine = Engine()

oChatBot = ChatBot("Chatterbot", storage_adapter="chatterbot.storage.SQLStorageAdapter")

#oChatBot.set_trainer(ChatterBotCorpusTrainer)
#oChatBot.train("chatterbot.corpus.chinese.GBT50297")


@engine.define
def hello(**params):
	if 'name' in params:
		return 'Hello, {}!'.format(params['name'])
	else:
		return 'Hello, LeanCloud!'


###############################################
@engine.define( 'chat' )
def chat(**paramsJson):
	#print(type(paramsJson))
	print(paramsJson)
	#print('>',len(paramsJson.get('msg')),paramsJson.get('msg'))
	question = paramsJson.get('msg')
	question = question.replace('什么是', '')
	question = question.replace('是什么', '')
	question = question.replace('?', '')
	question = question.replace('？', '')
	answer = get_answer(question)
	CHAT_CLASS.Add(paramsJson.get('openid'),paramsJson.get('msg'),answer)
	return answer

###############################################
def get_answer(sUserText):
	sRet = oChatBot.get_response(sUserText)
	print('<', sRet)
	return str(sRet)

###############################################
def crypto(paramsJson):
	#crypto_test()
	sessionKey = paramsJson.get('sessionKey')
	encryptedData = paramsJson.get('encryptedData')
	iv = paramsJson.get('iv')

###############################################
@engine.define( 'crypto' )
def cmd_crypto(paramsJson):
	#print(type(paramsJson))
	print(paramsJson.keys())
	#print paramsJson
	for k in paramsJson.keys():
		print( k,type(paramsJson.get(k)),paramsJson.get(k))
	crypto(paramsJson)
	return True

@engine.define( 'ls' )
def cmd_ls():
	OutputShell('ls -l')
	return True

@engine.define( 'top' )
def cmd_top():
	OutputShell('top -b -n 1 -H')
	return True

@engine.define( 'ps' )
def cmd_ps():
	OutputShell('ps -eLf')
	return True

@engine.define( 'cpuinfo' )
def cmd_cpuinfo():
	OutputShell('cat /etc/issue && cat /proc/cpuinfo')
	return True

@engine.define( 'shell' )
# 调试 {'cmd':'ls -l' }
def OutputShell( cmd, **params ):
	print( 'shell:',cmd)
	result = subprocess.Popen(
		#[ "ping 127.0.0.1" ],
		#[ "find /usr" ],
		[ cmd ],
		shell=True,
		stdout=subprocess.PIPE,
		stderr=subprocess.PIPE
	)
	# read date from pipe
	select_rfds = [ result.stdout, result.stderr ]
	while len( select_rfds ) > 0:
		(rfds, wfds, efds) = select.select( select_rfds, [ ], [ ] ) #select函数阻塞进程，直到select_rfds中的套接字被触发
		if result.stdout in rfds:
			readbuf_msg = result.stdout.readline()      #行缓冲
			if len( readbuf_msg ) == 0:
				select_rfds.remove( result.stdout )     #result.stdout需要remove，否则进程不会结束
			else:
				print( readbuf_msg)

		if result.stderr in rfds:
			readbuf_errmsg = result.stderr.readline()
			if len( readbuf_errmsg ) == 0:
				select_rfds.remove( result.stderr )     #result.stderr，否则进程不会结束
			else:
				print( readbuf_errmsg)
	result.wait() # 等待字进程结束( 等待shell命令结束 )
	#print result.returncode
	##(stdoutMsg,stderrMsg) = result .communicate()#非阻塞时读法.
	return result.returncode