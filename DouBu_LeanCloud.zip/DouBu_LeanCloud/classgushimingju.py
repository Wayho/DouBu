# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
# Standard library imports
import codecs
import time
import random

LIMIT_QUERY = 1000

########## Base Functions ##################
def Save_To_File(filename,text):
	ffile = codecs.open( filename, 'w', 'utf-8')
	ffile.write(text)
	ffile.close()

def Load_From_File(filename):
	ffile = codecs.open( filename, 'r', 'utf-8')
	text = ffile.read()
	ffile.close()
	return text

###################### Class Define #######################
class Class_GushiMingJu():
	# 处理 Chat Class的存取，没有属性，仅提供方法

	def Export_To_Json_For_MiniAppCloud(self):
		#{"Content":"山有木兮木有枝，心悦君兮君不知。","From":"佚名《越人歌》"}
        #{"Content":"人生若只如初见，何事秋风悲画扇。","From":"纳兰性德《木兰词·拟古决绝词柬友》"}
		MingJuClass = leancloud.Object.extend( self.__DBClassName )
		query = MingJuClass.query
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		#query.limit(5)  # 最多返回 LIMIT_QUERY 条结果
		page = 0
		sJsonStr = ''
		while (True):
			print( 'Page:', page,)
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			aFind = query.find()  # 查找descending
			print( 'Export_To_Json:', len(aFind))
			for gs in aFind:
				sJsonStr += '{"Content":"' + gs.get('Content') + '","From":"' + gs.get('From')+ '"}\n'
			#print(sJsonStr)
			if (len(aFind) < LIMIT_QUERY):
				break;
			page = page + 1
			time.sleep(5)
		Save_To_File('GuShiWen.json', sJsonStr)
		return

	def Get(self):
		# return str
		MingJuClass = leancloud.Object.extend( self.__DBClassName )
		query = MingJuClass.query
		aFind = query.find()
		for find in aFind:
			print(find.get('Content').replace('\r','\n'))
			print('***********')

	def Add(self, sContent, sFrom):
		# 返回 objectId
		# 检查存过没有
		MingJuClass = leancloud.Object.extend( self.__DBClassName )

		dB = MingJuClass()
		dB.set('Content', sContent)
		dB.set('From', sFrom)
		dB.save()
		return dB.id

	############## private #####
	def __init__(self):
		self.__DBClassName = "GuShiMingJu"


##########################Do not delete############################
GUSHIMINGJU_CLASS = Class_GushiMingJu()