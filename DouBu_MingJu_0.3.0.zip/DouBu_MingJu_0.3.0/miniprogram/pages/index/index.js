
const app = getApp()
const db = wx.cloud.database()
//console.log(app.globalData.userInfo)

Page({
    data: {
        openid: null,
        avatarUrl_doubu: './doubu.png',
        avatarUrl_unlogin: './user-unlogin.png',
        message: [],
        inputMsg: ">",
        scrollTop: 0,
        windowHeight:300
    },
    onLoad: function (options) {
        var message = wx.getStorageSync('message');
        var top = message.length * 200;
        this.setData({
            message: message || [{ type: 1, src: './doubu.png', content: '您好，欢迎来到兜布知道古诗文，这里有上万条经典名句，请点击发送开始欣赏之旅。' },],
            scrollTop: top,
            windowHeight: wx.getSystemInfoSync().windowHeight
        })
        //console.log(this.data.windowHeight)

    },
    onReady: function () {
        // 页面渲染完成
        //this.getOpenid();
        //console.log(this.data.openid);
    },
    onShow: function () {
        // 页面显示
        // 获取用户信息
    },
    onUnload: function () {
        wx.setStorageSync('message', this.data.message);
    },
    TransString: function (sSrc) {
        //return sSrc
        var sDest = ""
        var aContent = sSrc.split("，")
        //console.log(typeof (aContent), aContent.length,aContent)
        for (var ic = 0; ic < aContent.length - 1; ic++)
            //console.log(typeof (content), aContent[content])
            sDest += aContent[ic] + "，\n"
        sDest += aContent[aContent.length - 1]
        return sDest
    },
    getOpenid: function () {
        // 调用云函数
        wx.cloud.callFunction({
            name: 'openid',
            data: {},
            success: res => {
                //console.log('[openid] user openid: ', res.result.openid)
                this.setData({
                    openid: res.result.openid
                })
            },
            fail: err => {
                console.error('[openid] 调用失败', err)
            }
        })
    },
    bindChange: function (e) {
        this.setData({
            inputMsg: e.detail.value
        })
    },
    sendMessage: function (e) {
        //this.getOpenid();  
        this.setData({
            inputMsg: e.detail.value.input
        })
        var that = this;
        if (this.data.inputMsg != "") {
            var message = this.data.inputMsg
            var msg = { type: 0, src: 'avatarUrl', content: message };
            //发送信息
            this.setMessage(msg);
            //回复
            for (var ic = 0; ic < 3; ic++)
                this.sendMessage_Random()
        }
    },
    sendMessage_Random: function () {
        var index = parseInt(10000 * Math.random())
        while (0 == index)
            index = parseInt(10000 * Math.random())
        //console.log(index)

        db.collection('gushiwen')
            .skip(index) // 10000>i>0
            .limit(1) // 限制返回数量为 1 条
            .get()
            .then(res => {
                //console.log(res.data[0])
                var reply_str = this.TransString(res.data[0].Content)
                reply_str += '\n\n--' + res.data[0].From
                //console.log(typeof(reply_str),reply_str)                   
                var reply = { type: 1, src: this.data.avatarUrl_doubu, content: reply_str };
                this.setMessage(reply);

            })
            .catch(err => {
                console.error(err)
            })
    },
    setMessage: function (msg) {
        var msgList = this.data.message;
        msgList.push(msg);
        var top = this.data.message.length * 200;
        this.setData({
            message: msgList,
            inputMsg: ">"
       })
        this.setData({
            scrollTop: top
        })
    }
})