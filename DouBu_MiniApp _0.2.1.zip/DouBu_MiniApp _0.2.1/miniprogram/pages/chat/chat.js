const AV = require('../../utils/av-live-query-weapp-min');
const app = getApp()
//console.log(app.globalData.userInfo)

Page({
    data: {
        openid: null,
        avatarUrl_doubu: './doubu.png',
        avatarUrl_unlogin: './user-unlogin.png',
        message: [],
        inputMsg: "",
        scrollTop: 0
    },
    onLoad: function (options) {
        var message = wx.getStorageSync('message');
        var top = message.length * 100;
        this.setData({
            message: message || [{ type: 1, src: './doubu.png', content: '您好，欢迎来到电力兜布知道，由于服务器资源有限，回复可能需要2分钟时间，请耐心等待。' },],
            scrollTop: top
        })
        //console.log(app.globalData.userInfo)
        //console.log(app.globalData)
        //var reply = { type: 1, src: this.data.avatarUrl_doubu, content: "您好，欢迎来到电力兜布知道，由于服务器资源有限，回复可能需要2分钟时间，请耐心等待。" };
        //this.setMessage(reply);

    },
    onReady: function () {
        // 页面渲染完成
        this.getOpenid();
        //console.log(this.data.openid);
    },
    onShow: function () {
        // 页面显示
        // 获取用户信息
        //console.log(app.globalData.userInfo)      
    },
    onUnload: function () {
        wx.setStorageSync('message', this.data.message);
    },
    getOpenid: function () {
        // 调用云函数
        wx.cloud.callFunction({
            name: 'openid',
            data: {},
            success: res => {
                //console.log('[openid] user openid: ', res.result.openid)
                this.setData({
                    openid: res.result.openid
                })
            },
            fail: err => {
                console.error('[openid] 调用失败', err)
            }
        })
    },
    bindChange: function (e) {
        this.setData({
            inputMsg: e.detail.value
        })
    },
    sendMessage: function (e) {
        //this.getOpenid();  
        this.setData({
            inputMsg: e.detail.value.input
        })
        var that = this;
        if (this.data.inputMsg != "") {
            var message = this.data.inputMsg
            var msg = { type: 0, src: 'avatarUrl', content: message };
            //发送信息
            this.setMessage(msg);
            //回复
            if (this.data.openid)
                var paramsJson = { msg: message, openid: this.data.openid, avatarUrl: app.globalData.userInfo.avatarUrl};
            else
                var paramsJson = { msg: message, openid: '' };
            //const paramsJson = { msg: message };
            var promise = AV.Cloud.run('chat', paramsJson);
            promise.then(data => {
                // 调用成功，
                //console.log(data);
                var reply = { type: 1, src: this.data.avatarUrl_doubu, content: data };
                that.setMessage(reply);
            }).catch(error => console.error(error.message));
        }

        wx.clearStorageSync("message");
    },
    setMessage: function (msg) {
        var msgList = this.data.message;
        msgList.push(msg);
        this.setData({
            message: msgList,
            inputMsg: "",
        })
    }
})