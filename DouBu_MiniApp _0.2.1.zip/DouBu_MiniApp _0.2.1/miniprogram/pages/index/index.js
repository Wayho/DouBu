// miniprogram/pages/index/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
      userInfo: {},
      logged: false,
      message: [
          { type: 0, src: './user-unlogin.png', content: '电力兜布知道，都知道哪些知识？' },
          { type: 1, src: './doubu.png', content: '是的，兜布知道尽力做到电力知识全都知道，其它尽量都不知道。' },
          { type: 0, src: './user-unlogin.png', content: '回复怎么这么慢呢？' },
          { type: 1, src: './doubu.png', content: '由于服务器资源有限，回复可能需要2分钟时间，请耐心等待。' },

      ],
  },
    onGetUserInfo: function (e) {
        if (!this.logged && e.detail.userInfo) {
            this.setData({
                logged: true,
                //avatarUrl: e.detail.userInfo.avatarUrl,
                userInfo: e.detail.userInfo
            })
            app.globalData.userInfo = e.detail.userInfo
            wx.navigateTo({
                url: '../chat/chat',
            })
        }
        
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      //var logged = wx.getStorageSync('logged');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
      //wx.setStorageSync('logged', this.data.logged);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})